trabalho 5 robotica industrial 

Francisco Power nº84706
Pedro Rolo nº84803

existe um exercicio extra que é os feito para por os valores dos espaço carteciano e ver a movimentaçao do manipolador
