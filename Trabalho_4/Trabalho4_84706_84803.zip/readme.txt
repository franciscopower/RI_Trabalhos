Trabalho de Robotica Industrial 
Trabalho realizado por: 

Francisco Power nº84706
Pedro Rolo nº84803


Nesta pasta encontram-se 2 trabalhos extra:
1 - Extra_mais_movimentos
    -Uma sequêcia de movimentos realizados com um novo braço que permite rotação na base e a rotação do segundo elo é feita num eixo diferente, e onde o braço interage com outro objeto 

2- Extra_Angle_input
    -Extra onde se pode introduzir angulos, em graus, do espaço de juntas desejado (absoluto ou relativamente ao espaço anterior) manualmente através de uma GUI 
