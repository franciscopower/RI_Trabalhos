Robotica industrial

Alunos:Fracisco Power nº84706 e Pedro Rolo nº84803

- trabalho das alinias pedidas nas aulas 
- extra de possicionar atribuindo o valores dos angulos e movimentar assim o robo
- extra de movimento sincrunizado de 2 braços atraves de movimentos de juntas 
- extra inicializacao de posicionamento atraves de condenadas usado cordenadas polares 
