Trabalho nº6, Robotica Industrial
---------------------------------
Fracisco Power, nº84706
Pedro Rolo, nº84803
---------------------------------

Ex1abc.m - primeiras 3 alíneas do enunciado

Ex1d.m - última alínea do primeiro exercicio do enunciado (alínea principal)

Extra_coracao.m - manipulador de 6 eixo desenha um coração, usando equações paramétricas.

Extra_batman.m - manipulador de 6 eixo tenta desenhar os contornos de uma imagem obtidos no programa points_from_figure.m.
		Este desenho não fica perfeito, uma vez que a extração de pontos da imagem não é muito robusta.

Extra_desenho_livre.m - É pedido ao utilizador que defina vários pontos e o manipulador percorre esses pontos, por ordem, desenhando linhas retas entre eles.